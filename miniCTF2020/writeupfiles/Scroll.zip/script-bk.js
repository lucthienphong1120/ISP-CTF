((document) => {
    document.querySelector('.footer').innerHTML = String.fromCharCode(...[72, 105, 110, 116, 58, 32, 75, 233, 111, 32, 120, 117, 7889, 110, 103, 32, 110, 7919, 97, 32, 273, 105])
    document.addEventListener('DOMContentLoaded', () => {
        document.addEventListener('keyup', (e) => {
            e.preventDefault()
        })
        setInterval(() => {
            if (window.scrollY >= 8000) {
                window.scrollTo(0, 0)
            }
        });
    })
})(document)