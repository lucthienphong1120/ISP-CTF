<?php
$path = '327a6c4304ad5938eaf0efb6cc3e53dc.jpg';
if(isset($_GET['w']) && isset($_GET['h'])) {
	header("Content-Type: image/jpeg");
	resize_image($path, (int)$_GET['w'], (int)$_GET['h']);
} else {
	header('Content-Type: application/json');
	$result = new stdClass();
	$result->status = false;
	$result->message = 'Param invalid';
	echo json_encode($result, true);
}

function resize_image($image, $set_width, $set_height) {
    list($width, $height) = getimagesize($image);

	// Load
	$thumb = imagecreatetruecolor($set_width, $set_height);
	$source = imagecreatefromjpeg($image);

	// Resize
	imagecopyresized($thumb, $source, 0, 0, 0, 0, $set_width, $set_height, $width, $height);

	// Output
	imagejpeg($thumb);
}
 
