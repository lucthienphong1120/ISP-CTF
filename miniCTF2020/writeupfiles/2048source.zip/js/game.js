((document) => {
    document.addEventListener('DOMContentLoaded', () => {
        const showFlag = (data) => {
            document.querySelector('.game-explanation').innerHTML = data
        }
        const getFlag = (bestScore) => {
            return new Promise(resolve => {
                fetch('flag.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
                    },
                    body: `score=${encodeURIComponent(bestScore)}`
                })
                    .then(res => res.ok && res.json())
                    .then(res => res.status && showFlag(res.message))
                    .then(res => resolve())
            })
        }
        let setIntervalId = setInterval(() => {
            let bestScore = localStorage.getItem('bestScore')
            let gameState = JSON.parse(localStorage.getItem('gameState')) 
            if (gameState == null || (gameState.score === parseInt(bestScore) && bestScore >= 30102020) || (bestScore >= 30102020)) {
                getFlag(bestScore)
                    .then(clearInterval(setIntervalId))
            }
        }, 500)
    })
})(document)