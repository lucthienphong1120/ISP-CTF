<?php
header('Content-Type: application/json');

$best_score = 30102020; // Setup điểm cao nhất
$result = new stdClass();
$result->status = null;
$result->message = '';
if(isset($_POST)) {
	if(isset($_POST['score'])) {
		$score = $_POST['score'];
		if(gettype((int)$score) === 'integer') {
			$score_number = (int)$score;
			if($score_number >= $best_score) {
				$result->status = true;
				$result->message = 'Flag: ispclub{v3__v0i__d0i__cua__anh__d1_3m__e111__<333}';
			} else {
				$result->status = true;
				$result->message = 'Chưa đủ '.$best_score.' điểm nha, làm lại đi';
			}
		} else {
			$result->status = false;
			$result->message = 'Param \'score\'  incorrect'; 
		}
	} else {
		$result->status = false;
		$result->message = 'Param invalid'; 
	}
} else {
	$result->status = false;
	$result->message = 'Method invalid';
}

echo json_encode($result, TRUE);